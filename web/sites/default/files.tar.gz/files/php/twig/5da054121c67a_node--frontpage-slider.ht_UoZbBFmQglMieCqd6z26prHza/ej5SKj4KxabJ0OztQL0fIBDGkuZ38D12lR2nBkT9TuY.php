<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/custom/consulo_theme/templates/content/node--frontpage-slider.html.twig */
class __TwigTemplate_3afce32edd3920bede752297f76292de8ca4e5cced257d2a10366e633172fa2e extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = ["if" => 81];
        $filters = ["escape" => 74];
        $functions = ["attach_library" => 74];

        try {
            $this->sandbox->checkSecurity(
                ['if'],
                ['escape'],
                ['attach_library']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 73
        echo "
";
        // line 74
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\Core\Template\TwigExtension')->attachLibrary("consulo_theme/slick_slider"), "html", null, true);
        echo "

<div class=\"slider-item\">
    <div class=\"carousel-image-cover\">
        <div style=\"background-image:url(";
        // line 78
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_slider_image", []), 0, [], "array"), "#markup", [], "array")), "html", null, true);
        echo ")\" class=\"carousel-image\"></div>
    </div>
    <div class=\"slider-text-holder\">
        ";
        // line 81
        if ($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_slider_link", []), 0, [], "array")) {
            // line 82
            echo "            <a href=\"";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_slider_link", []), 0, [], "array"), "#url", [], "array")), "html", null, true);
            echo "\"><h2>";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["label"] ?? null)), "html", null, true);
            echo "</h2></a>
        ";
        } else {
            // line 84
            echo "            <h2>";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["label"] ?? null)), "html", null, true);
            echo "</h2>
        ";
        }
        // line 86
        echo "
      <div class=\"slider-description\">
        ";
        // line 88
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "body", [])), "html", null, true);
        echo "
      </div>
    ";
        // line 90
        if ($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_slider_link", []), 0, [], "array")) {
            // line 91
            echo "        ";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_slider_link", [])), "html", null, true);
            echo "
    ";
        }
        // line 93
        echo "    </div>

</div>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/consulo_theme/templates/content/node--frontpage-slider.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 93,  98 => 91,  96 => 90,  91 => 88,  87 => 86,  81 => 84,  73 => 82,  71 => 81,  65 => 78,  58 => 74,  55 => 73,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "themes/custom/consulo_theme/templates/content/node--frontpage-slider.html.twig", "/var/www/consulo.sk/web/themes/custom/consulo_theme/templates/content/node--frontpage-slider.html.twig");
    }
}
