<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/custom/consulo_theme/templates/views/views-view-fields--partner_quotes.html.twig */
class __TwigTemplate_830bd44e18d61e6c24768911618ef88c56e05208a23ddda8ae1f52478f5a1e54 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = ["if" => 34];
        $filters = ["escape" => 33, "trim" => 36, "striptags" => 36];
        $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['if'],
                ['escape', 'trim', 'striptags'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 32
        echo "
<div class=\"quote__text\"><p>";
        // line 33
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute(($context["fields"] ?? null), "field_quote_text", []), "content", [])), "html", null, true);
        echo "</p></div>
";
        // line 34
        if (($this->getAttribute(($context["fields"] ?? null), "field_quote_author", []) || $this->getAttribute(($context["fields"] ?? null), "field_quote_company", []))) {
            // line 35
            echo "  <div class=\"quote__author\">
    ";
            // line 36
            if (twig_trim_filter(strip_tags($this->getAttribute($this->getAttribute(($context["fields"] ?? null), "field_quote_author", []), "content", [])))) {
                // line 37
                echo "      <b class=\"quote__author-name\">";
                echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute(($context["fields"] ?? null), "field_quote_author", []), "content", [])), "html", null, true);
                echo "</b>
    ";
            }
            // line 39
            echo "    ";
            if (twig_trim_filter(strip_tags($this->getAttribute($this->getAttribute(($context["fields"] ?? null), "field_quote_company", []), "content", [])))) {
                // line 40
                echo "      <span class=\"quote__author-company\">";
                echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute(($context["fields"] ?? null), "field_quote_company", []), "content", [])), "html", null, true);
                echo "</span>
    ";
            }
            // line 42
            echo "  </div>
";
        }
    }

    public function getTemplateName()
    {
        return "themes/custom/consulo_theme/templates/views/views-view-fields--partner_quotes.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 42,  78 => 40,  75 => 39,  69 => 37,  67 => 36,  64 => 35,  62 => 34,  58 => 33,  55 => 32,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "themes/custom/consulo_theme/templates/views/views-view-fields--partner_quotes.html.twig", "/var/www/consulo.sk/web/themes/custom/consulo_theme/templates/views/views-view-fields--partner_quotes.html.twig");
    }
}
