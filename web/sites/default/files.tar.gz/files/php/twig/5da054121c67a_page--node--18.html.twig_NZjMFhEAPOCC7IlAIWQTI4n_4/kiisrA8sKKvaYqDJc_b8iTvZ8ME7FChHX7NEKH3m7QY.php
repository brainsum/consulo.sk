<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/custom/consulo_theme/templates/layout/page--node--18.html.twig */
class __TwigTemplate_3926cc52d790cdd81dc4901f18619e597f7476cae0292176385ec964ca799533 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = [];
        $filters = ["escape" => 50];
        $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doGetParent(array $context)
    {
        // line 46
        return "page.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("page.html.twig", "themes/custom/consulo_theme/templates/layout/page--node--18.html.twig", 46);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 48
    public function block_main($context, array $blocks = [])
    {
        // line 49
        echo "  <div class=\"layout-content\">
    ";
        // line 50
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["page"] ?? null), "content", [])), "html", null, true);
        echo "
  </div>";
        // line 52
        echo "
  <div class=\"contact-map\">
    <iframe src=\"https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1334.7839297476844!2d17.622699!3d48.002738!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xeb6bea94356e156e!2sConsulo%2C+s.r.o.!5e0!3m2!1sen!2sus!4v1558449374829!5m2!1sen!2sus&output=embed\" width=\"100%\" height=\"400\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>
  </div>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/consulo_theme/templates/layout/page--node--18.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 52,  70 => 50,  67 => 49,  64 => 48,  54 => 46,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "themes/custom/consulo_theme/templates/layout/page--node--18.html.twig", "/var/www/consulo.sk/web/themes/custom/consulo_theme/templates/layout/page--node--18.html.twig");
    }
}
