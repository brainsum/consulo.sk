<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/custom/consulo_theme/templates/content/node--19.html.twig */
class __TwigTemplate_5cf1efff589334f0b8ac6eae636e02ae09f3ebbd59cd59dc7417ff8297dd28c5 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = ["set" => 74, "if" => 87];
        $filters = ["clean_class" => 76, "escape" => 83];
        $functions = ["attach_library" => 83];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['clean_class', 'escape'],
                ['attach_library']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 74
        $context["classes"] = [0 => "node", 1 => ("node--type-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed($this->getAttribute(        // line 76
($context["node"] ?? null), "bundle", [])))), 2 => (($this->getAttribute(        // line 77
($context["node"] ?? null), "isPromoted", [], "method")) ? ("node--promoted") : ("")), 3 => (($this->getAttribute(        // line 78
($context["node"] ?? null), "isSticky", [], "method")) ? ("node--sticky") : ("")), 4 => (( !$this->getAttribute(        // line 79
($context["node"] ?? null), "isPublished", [], "method")) ? ("node--unpublished") : ("")), 5 => ((        // line 80
($context["view_mode"] ?? null)) ? (("node--view-mode-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(($context["view_mode"] ?? null))))) : (""))];
        // line 83
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\Core\Template\TwigExtension')->attachLibrary("classy/node"), "html", null, true);
        echo "
<article";
        // line 84
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["attributes"] ?? null), "addClass", [0 => ($context["classes"] ?? null)], "method")), "html", null, true);
        echo ">

  ";
        // line 86
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null)), "html", null, true);
        echo "
  ";
        // line 87
        if ( !($context["page"] ?? null)) {
            // line 88
            echo "    <h2";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_attributes"] ?? null)), "html", null, true);
            echo ">
      <a href=\"";
            // line 89
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["url"] ?? null)), "html", null, true);
            echo "\" rel=\"bookmark\">";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["label"] ?? null)), "html", null, true);
            echo "</a>
    </h2>
  ";
        }
        // line 92
        echo "  ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null)), "html", null, true);
        echo "

  <div";
        // line 94
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content_attributes"] ?? null), "addClass", [0 => "node__content"], "method")), "html", null, true);
        echo ">
    <section class=\"about-section\">
      <div class=\"section__inner\">
        <div class=\"section__content\">
          ";
        // line 98
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_carrier_about", [])), "html", null, true);
        echo "
          ";
        // line 99
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_carrier_more_button", [])), "html", null, true);
        echo "
        </div>
        <div class=\"section__illustration\">
          <img src=\"/";
        // line 102
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["directory"] ?? null)), "html", null, true);
        echo "/images/consulo_team--grayscale.png\" alt=\"Consulo Team in black & white\">
        </div>
      </div>
    </section>
    <section class=\"carrier-boxes-section\">
      <div class=\"section__inner\">
        ";
        // line 108
        if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_carrier_title_left", []), "#items", [], "array"), "getValue", [], "method") || $this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_carrier_box_left", []), "#items", [], "array"), "getValue", [], "method"))) {
            // line 109
            echo "          <article class=\"carrier-box carrier-box--left\">
        ";
        }
        // line 111
        echo "          ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_carrier_title_left", [])), "html", null, true);
        echo "
          ";
        // line 112
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_carrier_box_left", [])), "html", null, true);
        echo "
        ";
        // line 113
        if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_carrier_title_left", []), "#items", [], "array"), "getValue", [], "method") || $this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_carrier_box_left", []), "#items", [], "array"), "getValue", [], "method"))) {
            // line 114
            echo "          </article>
        ";
        }
        // line 116
        echo "        ";
        if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_carrier_title_right", []), "#items", [], "array"), "getValue", [], "method") || $this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_carrier_box_right", []), "#items", [], "array"), "getValue", [], "method"))) {
            // line 117
            echo "          <article class=\"carrier-box carrier-box--right\">
        ";
        }
        // line 119
        echo "          ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_carrier_title_right", [])), "html", null, true);
        echo "
          ";
        // line 120
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_carrier_box_right", [])), "html", null, true);
        echo "
        ";
        // line 121
        if (($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_carrier_title_right", []), "#items", [], "array"), "getValue", [], "method") || $this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_carrier_box_right", []), "#items", [], "array"), "getValue", [], "method"))) {
            // line 122
            echo "          </article>
        ";
        }
        // line 124
        echo "      </div>
    </section>
    <section class=\"contact-section\">
      <div class=\"section__inner\">
        ";
        // line 128
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_carrier_callout", [])), "html", null, true);
        echo "
        ";
        // line 129
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_carrier_phone", [])), "html", null, true);
        echo "
        ";
        // line 130
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_carrier_email", [])), "html", null, true);
        echo "
      </div>
    </section>
  </div>
</article>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/consulo_theme/templates/content/node--19.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  179 => 130,  175 => 129,  171 => 128,  165 => 124,  161 => 122,  159 => 121,  155 => 120,  150 => 119,  146 => 117,  143 => 116,  139 => 114,  137 => 113,  133 => 112,  128 => 111,  124 => 109,  122 => 108,  113 => 102,  107 => 99,  103 => 98,  96 => 94,  90 => 92,  82 => 89,  77 => 88,  75 => 87,  71 => 86,  66 => 84,  62 => 83,  60 => 80,  59 => 79,  58 => 78,  57 => 77,  56 => 76,  55 => 74,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "themes/custom/consulo_theme/templates/content/node--19.html.twig", "/var/www/consulo.sk/web/themes/custom/consulo_theme/templates/content/node--19.html.twig");
    }
}
