<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/custom/consulo_theme/templates/content/node--team-member.html.twig */
class __TwigTemplate_ce0681ce0eba12eddc64ef886f374cba0d377561a6c5c961a3d2114a39d2444e extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = ["set" => 74, "if" => 91];
        $filters = ["clean_class" => 76, "escape" => 83];
        $functions = ["attach_library" => 83];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['clean_class', 'escape'],
                ['attach_library']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 74
        $context["classes"] = [0 => "node", 1 => ("node--type-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed($this->getAttribute(        // line 76
($context["node"] ?? null), "bundle", [])))), 2 => (($this->getAttribute(        // line 77
($context["node"] ?? null), "isPromoted", [], "method")) ? ("node--promoted") : ("")), 3 => (($this->getAttribute(        // line 78
($context["node"] ?? null), "isSticky", [], "method")) ? ("node--sticky") : ("")), 4 => (( !$this->getAttribute(        // line 79
($context["node"] ?? null), "isPublished", [], "method")) ? ("node--unpublished") : ("")), 5 => ((        // line 80
($context["view_mode"] ?? null)) ? (("node--view-mode-" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(($context["view_mode"] ?? null))))) : (""))];
        // line 83
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\Core\Template\TwigExtension')->attachLibrary("classy/node"), "html", null, true);
        echo "
";
        // line 84
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\Core\Template\TwigExtension')->attachLibrary("consulo_theme/slick_slider"), "html", null, true);
        echo "
<article";
        // line 85
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["attributes"] ?? null), "addClass", [0 => ($context["classes"] ?? null)], "method")), "html", null, true);
        echo ">
  ";
        // line 86
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_prefix"] ?? null)), "html", null, true);
        echo "
  ";
        // line 87
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["title_suffix"] ?? null)), "html", null, true);
        echo "
  <div class=\"image-holder\">
    <div class=\"image-text\">
      ";
        // line 90
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "body", [])), "html", null, true);
        echo "
      ";
        // line 91
        if ($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_praxis", []), 0, [], "array")) {
            // line 92
            echo "        ";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_praxis", [])), "html", null, true);
            echo "
      ";
        }
        // line 94
        echo "    </div>
    <div class=\"";
        // line 95
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ("slick_slider_" . $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute(($context["elements"] ?? null), "#node", [], "array"), "id", []))), "html", null, true);
        echo "\">
      ";
        // line 96
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_image", [])), "html", null, true);
        echo "
    </div>
  </div>
  <div class=\"text-holder\">
    <div class=\"text-holder--name\">
      ";
        // line 101
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["label"] ?? null), 0, [], "array"), "#context", [], "array"), "value", [])), "html", null, true);
        echo "
      ";
        // line 102
        if ($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_position", []), 0, [], "array"), "#context", [], "array"), "value", [])) {
            // line 103
            echo "        <span>";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_position", []), 0, [], "array"), "#context", [], "array"), "value", [])), "html", null, true);
            echo "</span>
      ";
        }
        // line 105
        echo "    </div>
    <div class=\"text-holder--mobile\">
      ";
        // line 107
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "body", [])), "html", null, true);
        echo "
      ";
        // line 108
        if ($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_praxis", []), 0, [], "array")) {
            // line 109
            echo "        ";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "field_praxis", [])), "html", null, true);
            echo "
      ";
        }
        // line 111
        echo "    </div>
    <div class=\"text-holder--data\">
      ";
        // line 113
        if ($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_email_address", []), 0, [], "array")) {
            // line 114
            echo "        <a class=\"icon-rounded\" href=\"mailto:";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_email_address", []), 0, [], "array"), "#context", [], "array"), "value", [])), "html", null, true);
            echo "\"><i class=\"fa fa-envelope\"></i></a>
      ";
        }
        // line 116
        echo "      ";
        if ($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_facebook_link", []), 0, [], "array")) {
            // line 117
            echo "        <a class=\"icon-rounded\" href=\"";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_facebook_link", []), 0, [], "array"), "#url_title", [], "array")), "html", null, true);
            echo "\" target=\"_blank\"><i class=\"fab fa-facebook-f\"></i></a>
      ";
        }
        // line 119
        echo "      ";
        if ($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_phone", []), 0, [], "array"), "#context", [], "array"), "value", [])) {
            // line 120
            echo "        <a class=\"icon-phone\" href=\"tel:";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_phone", []), 0, [], "array"), "#context", [], "array"), "value", [])), "html", null, true);
            echo "\"><i class=\"fas fa-phone fa-flip-horizontal\"></i> ";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["content"] ?? null), "field_phone", []), 0, [], "array"), "#context", [], "array"), "value", [])), "html", null, true);
            echo "</a>
      ";
        }
        // line 122
        echo "    </div>
  </div>
</article>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/consulo_theme/templates/content/node--team-member.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  171 => 122,  163 => 120,  160 => 119,  154 => 117,  151 => 116,  145 => 114,  143 => 113,  139 => 111,  133 => 109,  131 => 108,  127 => 107,  123 => 105,  117 => 103,  115 => 102,  111 => 101,  103 => 96,  99 => 95,  96 => 94,  90 => 92,  88 => 91,  84 => 90,  78 => 87,  74 => 86,  70 => 85,  66 => 84,  62 => 83,  60 => 80,  59 => 79,  58 => 78,  57 => 77,  56 => 76,  55 => 74,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "themes/custom/consulo_theme/templates/content/node--team-member.html.twig", "/var/www/consulo.sk/web/themes/custom/consulo_theme/templates/content/node--team-member.html.twig");
    }
}
